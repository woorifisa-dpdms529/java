package studyroomReservation;

public class Desk {
	// 좌석 번호
	private int id;
	// 날짜 & 시간
	private Date date;
	// 예약 여부
	private boolean isReservated = false;
	// 예약자 정보
	private User user;

	public Desk(int id, Date date) {
		this.id = id;
		this.date = date;
	}
	
	// 예약
	void reserve(User user) {
		if(isReservated) {
			System.out.println("이미 예약된 좌석입니다.");
		}else {
			isReservated = true;
			this.user = user;
 			String dateInfo = date.getYear() + "/" + date.getMonth() + "/" + date.getDay() + " " + date.getTime() + "시";
			System.out.println(dateInfo + " " + id + "번 좌석이 예약이 완료되었습니다.\n");
		}
	}
	
	

	public int getId() {
		return id;
	}

	public Date getDate() {
		return date;
	}

	public boolean isReservated() {
		return isReservated;
	}

	public User getUser() {
		return user;
	}


	@Override
	public String toString() {
		String dateInfo = date.getYear() + "/" + date.getMonth() + "/" + date.getDay() + " " + date.getTime() + "시";
		String reservationInfo = isReservated?"예약완료":"예약가능";
		
		String message = "날짜 시간 : " + dateInfo + "\n" + 
				"좌석 번호:" + id + "\n" + 
				reservationInfo + "\n";
		
		if(user != null) {
			message += "신청자 : " + user.getName() + "\n";
		}

		return message;
	}
	
	
}
