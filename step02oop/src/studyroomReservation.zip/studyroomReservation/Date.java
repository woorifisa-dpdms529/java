package studyroomReservation;

public class Date {
	// 년
	private int year;
	// 월
	private int month;
	// 일
	private int day;
	// 시간
	private int time;
	
	public Date(int year, int month, int day, int time) {
		this.year = year;
		this.month = month;
		this.day = day;
		this.time = time;
	}

	public int getYear() {
		return year;
	}

	public int getMonth() {
		return month;
	}

	public int getDay() {
		return day;
	}

	public int getTime() {
		return time;
	}
	
	
}
